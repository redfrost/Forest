/* Author: Alex Lim. Custom codes */


// Menu Sublevel Indicator
	  	jQuery(function($){
	    		$('.menu li:has(".sub-menu")').addClass('has-sub-menu');
	  		});


// Menu Last Child Addition
				/* <![CDATA[ */
				jQuery(document).ready( function($) {
					$('.menu > li:first-child').addClass('first-item');
					$('.menu > li:last-child').addClass('last-item');
					} );
				/* ]]> */


	
// Bootstrap Tooltip
	  jQuery(document).ready(function () {
	    $("[rel=tooltip]").tooltip();
	  });

	
// Bootstrap Popover
	  jQuery(document).ready(function () {
	    $("[rel=popover]").popover();
	  });

		

// Mobile view fixed width + Zoom enabler
/*	var mobile_timer = false;
	if(navigator.userAgent.match(/iPhone/i)) {
		$('#viewport').attr('content','width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0');
		$(window).bind('gesturestart',function () {
			clearTimeout(mobile_timer);
			$('#viewport').attr('content','width=device-width,minimum-scale=1.0,maximum-scale=10.0');
		}).bind('touchend',function () {
			clearTimeout(mobile_timer);
			mobile_timer = setTimeout(function () {
				$('#viewport').attr('content','width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0');
			},1000);
		});
	}
*/