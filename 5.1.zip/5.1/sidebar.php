<div class="well">
  <?php dynamic_sidebar('sidebar-primary'); ?>
</div>