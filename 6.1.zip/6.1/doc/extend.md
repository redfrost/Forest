[Roots Theme homepage](http://www.rootstheme.com/) | [Documentation
table of contents](TOC.md)

# Extend and customize Roots
Here is some useful advice for how you can make your project with Roots even better.

* [Recommended plugins](plugins.md)

