<?php
/*
Template Name: Featured - Top Large Thumbnail 
*/
?>

<?php get_template_part('templates/content', 'page'); ?>